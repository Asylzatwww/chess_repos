<?php
#------------------------------------------------------------------------------------------#
#  Copyright (c) Dr. R. Urban                                                              #
#  24.05.2015                                                                              #
#  Web-GUI-for-stockfish-chess                                                             #
#  https://github.com/antiproton                                                           #
#  Released under the MIT license                                                          #
#  https://github.com/antiproton/Web-GUI-for-stockfish-chess/blob/master/LICENSE           #
#  http://www.genialschach.de/                                                             #
#------------------------------------------------------------------------------------------#
$security_code = "1534";
#------------------------------------
$pfad_stockfish  = "C:/xampp/htdocs/netreal/Stockfish/src/stockfish.exe";
#$pfad_stockfish   = "/kunden/homepages/38/d375266227/htdocs/netreal/Stockfish/src/stockfish";
#------------------------------------
$thinking_time = 500; # milliseconds
#------------------------------------

?>